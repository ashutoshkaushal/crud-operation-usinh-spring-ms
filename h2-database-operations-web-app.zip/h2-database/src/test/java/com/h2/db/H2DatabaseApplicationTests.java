package com.h2.db;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class H2DatabaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
